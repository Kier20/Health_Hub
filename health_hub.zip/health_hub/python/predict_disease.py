import pymysql
from flask import Flask, request, jsonify, session

# Initialize Flask app
app = Flask(__name__)
app.secret_key = "your_secret_key"

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'health_hub',
    'cursorclass': pymysql.cursors.DictCursor
}

class DiseasePredictor:
    def __init__(self, db_config):
        self.db_config = db_config

    def predict_disease(self, symptoms, last_name):
        predicted_diseases = []
        try:
            # Connect to the database
            with pymysql.connect(**self.db_config) as connection:
                cursor = connection.cursor()

                # Fetch diseases that match the provided symptoms and last_name
                query = """
                    SELECT d.name 
                    FROM diseases d
                    JOIN disease_symptoms ds ON d.symptoms = ds.symptoms 
                    WHERE ds.processed = 0 AND ds.lastname = %s
                """
                cursor.execute(query, (last_name,))
                rows = cursor.fetchall()

                for row in rows:
                    predicted_diseases.append(row['name'])

                # Update processed column to true for the user's symptoms
                update_query = "UPDATE disease_symptoms SET processed = 1 WHERE symptoms = %s AND lastname = %s"
                cursor.execute(update_query, (symptoms, last_name))
                connection.commit()

        except Exception as e:
            print("Error:", e)
            raise  # Re-raise the exception to propagate it

        return predicted_diseases

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Retrieve symptoms from the POST request
        symptoms = request.json.get('symptoms')
        if not symptoms:
            return jsonify({"error": "Symptoms not provided"})

        # Retrieve last_name from the session
        last_name = session.get('last_name')
        if not last_name:
            return jsonify({"error": "Last name not found in session data"})

        # Instantiate DiseasePredictor with proper db_config
        predictor = DiseasePredictor(db_config)
        
        # Predict diseases based on symptoms and last_name
        predicted_diseases = predictor.predict_disease(symptoms, last_name)
        
        # Return the predicted diseases
        return jsonify({"predicted_diseases": predicted_diseases})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)